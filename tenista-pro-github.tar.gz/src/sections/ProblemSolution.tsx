import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { X, Check, Brain, Target, Zap, BookOpen } from 'lucide-react';

const ProblemSolution = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const problems = [
    'Perde partidas por não controlar a pressão mental',
    'Erra bolas fáceis em momentos decisivos',
    'Saque inconsistente com muitas duplas faltas',
    'Forehand que funciona em treino mas erra em jogo',
    'Backhand fraco que vira alvo do adversário',
  ];

  const solutions = [
    'Mentalidade de campeão para vencer sob pressão',
    'Protocolos práticos de psicologia do esporte',
    'Método específico para cada golpe do seu jogo',
    'Drills práticos e planos de evolução claros',
    'Técnicas usadas por atletas de alto rendimento',
  ];

  return (
    <section ref={ref} className="relative py-16 sm:py-24 bg-[#0A0A0A] overflow-hidden" id="problem">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A0A] via-[#0D0D0D] to-[#0A0A0A]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-20">
          {/* Problem Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                <X className="w-4 h-4 sm:w-5 sm:h-5 text-red-500" />
              </div>
              <span className="text-red-500 font-semibold text-xs sm:text-sm tracking-wider">O PROBLEMA</span>
            </div>

            <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-6 sm:mb-8 leading-tight">
              Você treina, mas não consegue levar seu melhor jogo para as quadras?
            </h2>

            <div className="space-y-2 sm:space-y-4">
              {problems.map((problem, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-3 sm:gap-4 p-3 sm:p-4 rounded-lg sm:rounded-xl bg-[#141414] border border-red-500/20"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                >
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <X className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-red-500" />
                  </div>
                  <span className="text-gray-300 text-sm sm:text-base">{problem}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Divider - Mobile Horizontal */}
          <div className="flex lg:hidden items-center justify-center py-2">
            <div className="w-full h-px bg-gradient-to-r from-transparent via-[#CCFF00]/50 to-transparent" />
          </div>

          {/* Divider - Desktop Vertical */}
          <div className="hidden lg:flex items-center justify-center">
            <div className="w-px h-full bg-gradient-to-b from-transparent via-[#CCFF00]/50 to-transparent" />
          </div>

          {/* Solution Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-[#CCFF00]/10 flex items-center justify-center">
                <Check className="w-4 h-4 sm:w-5 sm:h-5 text-[#CCFF00]" />
              </div>
              <span className="text-[#CCFF00] font-semibold text-xs sm:text-sm tracking-wider">A SOLUÇÃO</span>
            </div>

            <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-6 sm:mb-8 leading-tight">
              Transforme sua mentalidade E técnica com nossos e-books.
            </h2>

            <div className="space-y-2 sm:space-y-4">
              {solutions.map((solution, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-3 sm:gap-4 p-3 sm:p-4 rounded-lg sm:rounded-xl bg-[#141414] border border-[#CCFF00]/20 card-hover"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
                >
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-[#CCFF00]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Check className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-[#CCFF00]" />
                  </div>
                  <span className="text-gray-300 text-sm sm:text-base">{solution}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Stats Row */}
        <motion.div
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 sm:gap-4 mt-12 sm:mt-20"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          {[
            { icon: Brain, value: '1', label: 'Mentalidade' },
            { icon: Target, value: 'Saque', label: 'Técnico' },
            { icon: Zap, value: 'Forehand', label: 'Técnico' },
            { icon: BookOpen, value: 'Backhand', label: 'Técnico' },
            { icon: Check, value: '100%', label: 'Prático' },
          ].map((stat, index) => (
            <div
              key={index}
              className="text-center p-3 sm:p-5 rounded-xl sm:rounded-2xl bg-[#141414] border border-[#2A2A2A]"
            >
              <stat.icon className="w-4 h-4 sm:w-5 sm:h-5 text-[#CCFF00] mx-auto mb-1 sm:mb-2" />
              <div className="text-base sm:text-lg font-bold text-white mb-0.5">{stat.value}</div>
              <div className="text-[10px] sm:text-xs text-gray-500">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default ProblemSolution;
