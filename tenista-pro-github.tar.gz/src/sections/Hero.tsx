import { motion } from 'framer-motion';
import { BookOpen, Check, Sparkles, Star, Brain } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero = () => {
  const scrollToMainProduct = () => {
    const element = document.getElementById('main-product');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToProducts = () => {
    const element = document.getElementById('technical-products');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  const headlineWords = ['MENTALIDADE', 'DE', 'ATLETA', 'PROFISSIONAL'];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0A0A0A]">
      {/* Floating Orbs Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute -top-20 -left-20 w-[300px] h-[300px] sm:w-[500px] sm:h-[500px] rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(204, 255, 0, 0.4) 0%, transparent 70%)',
            filter: 'blur(100px)',
          }}
          animate={{
            x: [0, 30, -20, 0],
            y: [0, -40, 20, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        <motion.div
          className="absolute top-1/3 -right-20 w-[250px] h-[250px] sm:w-[400px] sm:h-[400px] rounded-full opacity-15"
          style={{
            background: 'radial-gradient(circle, rgba(158, 249, 22, 0.4) 0%, transparent 70%)',
            filter: 'blur(80px)',
          }}
          animate={{
            x: [0, -20, 30, 0],
            y: [0, 30, -20, 0],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        <motion.div
          className="absolute -bottom-10 left-1/4 w-[200px] h-[200px] sm:w-[300px] sm:h-[300px] rounded-full opacity-10"
          style={{
            background: 'radial-gradient(circle, rgba(204, 255, 0, 0.3) 0%, transparent 70%)',
            filter: 'blur(60px)',
          }}
          animate={{
            x: [0, 40, -30, 0],
            y: [0, -30, 40, 0],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white/20 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.5, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left order-2 lg:order-1">
            {/* Badge Principal */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            >
              <span className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full border border-[#CCFF00]/40 bg-[#CCFF00]/10 text-[#CCFF00] text-xs sm:text-sm font-medium mb-4 sm:mb-6">
                <Star className="w-3 h-3 sm:w-4 sm:h-4" />
                E-BOOK BESTSELLER
              </span>
            </motion.div>

            {/* Headline with word-by-word animation */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-4 sm:mb-6">
              {headlineWords.map((word, index) => (
                <motion.span
                  key={index}
                  className="inline-block mr-2 sm:mr-3"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.6,
                    delay: 0.2 + index * 0.08,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  {word}
                </motion.span>
              ))}
            </h1>

            {/* Subheadline */}
            <motion.p
              className="text-base sm:text-lg lg:text-xl text-gray-400 mb-4 sm:mb-6 max-w-xl mx-auto lg:mx-0 px-2 sm:px-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
            >
              Descubra os segredos da psicologia do esporte que os campeões usam para vencer sob pressão. 
              <strong className="text-white"> 17 capítulos, 145 páginas</strong> de conteúdo transformador.
            </motion.p>

            {/* E-books Técnicos Badge */}
            <motion.div
              className="flex items-center gap-2 text-[#CCFF00] mb-6 sm:mb-8 justify-center lg:justify-start"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7, ease: [0.16, 1, 0.3, 1] }}
            >
              <Brain className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-xs sm:text-sm font-medium">+ E-books Técnicos: Saque, Forehand e Backhand</span>
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              className="flex flex-col sm:flex-row gap-3 sm:gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8, ease: [0.16, 1, 0.3, 1] }}
            >
              <Button
                onClick={scrollToMainProduct}
                className="bg-[#CCFF00] text-black hover:bg-[#9EF916] px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg font-bold rounded-xl animate-pulse-glow transition-transform hover:scale-105"
              >
                <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                QUERO O E-BOOK PRINCIPAL
              </Button>
              <Button
                onClick={scrollToProducts}
                variant="outline"
                className="border-[#2A2A2A] text-white hover:bg-[#141414] hover:border-[#CCFF00]/30 px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg font-semibold rounded-xl"
              >
                <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                VER TODOS OS PRODUTOS
              </Button>
            </motion.div>

            {/* Trust Badges */}
            <motion.div
              className="flex flex-wrap gap-3 sm:gap-4 mt-6 sm:mt-8 justify-center lg:justify-start"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.9, ease: [0.16, 1, 0.3, 1] }}
            >
              {[
                '17 capítulos completos',
                '145 páginas',
                'Acesso imediato',
              ].map((badge, index) => (
                <div key={index} className="flex items-center gap-1.5 sm:gap-2 text-gray-500 text-xs sm:text-sm">
                  <Check className="w-3 h-3 sm:w-4 sm:h-4 text-[#CCFF00]" />
                  <span>{badge}</span>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right Content - Main E-book Mockup */}
          <motion.div
            className="relative flex justify-center lg:justify-end order-1 lg:order-2"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="relative">
              {/* Glow behind mockup */}
              <div className="absolute inset-0 bg-[#CCFF00]/20 blur-[60px] sm:blur-[100px] rounded-full scale-75" />
              
              {/* Main E-book Image */}
              <motion.img
                src="/ebook-mockup.png"
                alt="Mentalidade de Atleta Profissional no Tênis"
                className="relative z-10 w-[280px] sm:w-[350px] md:w-[400px] lg:w-full lg:max-w-md drop-shadow-2xl mx-auto"
                animate={{
                  y: [0, -10, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              />

              {/* Floating Technical E-books */}
              <motion.div
                className="absolute -bottom-2 -right-2 sm:-bottom-4 sm:-right-4 bg-[#141414] border border-[#2A2A2A] rounded-lg sm:rounded-xl p-2 sm:p-3 shadow-xl"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 1 }}
              >
                <p className="text-[10px] sm:text-xs text-gray-400 mb-1">+ Disponíveis</p>
                <div className="flex gap-1 sm:gap-2">
                  {['Saque', 'Forehand', 'Backhand'].map((item, i) => (
                    <span key={i} className="px-1.5 sm:px-2 py-0.5 sm:py-1 bg-[#CCFF00]/10 text-[#CCFF00] text-[10px] sm:text-xs rounded">
                      {item}
                    </span>
                  ))}
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
      >
        <motion.div
          className="w-5 h-8 sm:w-6 sm:h-10 border-2 border-gray-600 rounded-full flex justify-center pt-1.5 sm:pt-2"
          animate={{ y: [0, 5, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <motion.div className="w-1 h-1 sm:w-1.5 sm:h-1.5 bg-[#CCFF00] rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;
