import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { MessageSquare, Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const testimonials = [
    {
      name: 'Carlos M.',
      role: 'Tenista Amador',
      avatar: 'CM',
      content: 'Depois de aplicar os protocolos do e-book, minha consistência em jogos melhorou drasticamente. Consegui manter a calma em tiebreaks decisivos e finalmente venci um torneio que participo há anos.',
      rating: 5,
    },
    {
      name: 'Ana P.',
      role: 'Competidora',
      avatar: 'AP',
      content: 'Finalmente entendi por que eu jogava pior quando estava ganhando. O capítulo sobre ansiedade antecipatória foi um divisor de águas para minha performance. Recomendo para todo tenista sério.',
      rating: 5,
    },
    {
      name: 'Ricardo S.',
      role: 'Professor de Tênis',
      avatar: 'RS',
      content: 'Recomendo para todos os meus alunos. A abordagem é prática, baseada em ciência e realmente funciona em quadra. O ritual entre pontos mudou completamente a forma como meus alunos competem.',
      rating: 5,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: [0.16, 1, 0.3, 1] as const,
      },
    },
  };

  return (
    <section ref={ref} className="relative py-24 bg-[#141414] overflow-hidden" id="testimonials">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#CCFF00]/5 rounded-full blur-[200px]" />
      </div>

      {/* Quote Decoration */}
      <div className="absolute top-10 right-10 opacity-5">
        <Quote className="w-32 h-32 text-[#CCFF00]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <MessageSquare className="w-5 h-5 text-[#CCFF00]" />
            <span className="text-[#CCFF00] font-semibold text-sm tracking-wider">DEPOIMENTOS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white">
            O Que os Leitores Estão <span className="text-gradient">Dizendo</span>
          </h2>
        </motion.div>

        {/* Testimonials Grid */}
        <motion.div
          className="grid md:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              variants={cardVariants}
              className="group relative p-6 rounded-2xl bg-[#0A0A0A] border border-[#2A2A2A] card-hover"
            >
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 opacity-10">
                <Quote className="w-8 h-8 text-[#CCFF00]" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#CCFF00] text-[#CCFF00]" />
                ))}
              </div>

              {/* Content */}
              <p className="text-gray-300 leading-relaxed mb-6 text-sm">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-[#2A2A2A]">
                <div className="w-10 h-10 rounded-full bg-[#CCFF00]/20 flex items-center justify-center">
                  <span className="text-[#CCFF00] font-bold text-sm">{testimonial.avatar}</span>
                </div>
                <div>
                  <div className="text-white font-medium text-sm">{testimonial.name}</div>
                  <div className="text-gray-500 text-xs">{testimonial.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Trust Indicators */}
        <motion.div
          className="mt-16 flex flex-wrap justify-center gap-8"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          {[
            { value: '500+', label: 'Leitores' },
            { value: '4.9', label: 'Avaliação Média' },
            { value: '97%', label: 'Recomendam' },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-2xl font-bold text-[#CCFF00]">{stat.value}</div>
              <div className="text-gray-500 text-sm">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;
