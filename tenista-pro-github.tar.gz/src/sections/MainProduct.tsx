import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Star, Check, Sparkles, Shield, BookOpen, Brain, Target, Clock, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';

const MainProduct = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const chapters = [
    'Por que o jogo mental decide partidas',
    'Fundamentos da Psicologia do Esporte',
    'Como o cérebro reage à pressão',
    'Os 3 sabotadores mentais do tenista',
    'Atenção, foco e controle do presente',
    'O ritual do atleta profissional',
    'Como manter performance quando está ganhando',
    'Como lidar com erros em bolas fáceis',
    'Como jogar contra adversários "mais fracos"',
    'Regulação emocional em jogos decisivos',
    'Linguagem interna e autoconfiança',
    'Visualização, respiração e ancoragem',
    'Construção de identidade de atleta',
    'Rotina mental pré, durante e pós-jogo',
    'Plano de evolução mental em 30 dias',
    'Checklists práticos para imprimir',
    'Como sustentar uma mente forte',
  ];

  const features = [
    { icon: BookOpen, label: '17 Capítulos' },
    { icon: Clock, label: '145 Páginas' },
    { icon: Target, label: '30 Dias de Plano' },
    { icon: Award, label: 'Checklists' },
  ];

  return (
    <section ref={ref} className="relative py-16 sm:py-24 bg-[#141414] overflow-hidden" id="main-product">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-64 h-64 sm:w-96 sm:h-96 bg-[#CCFF00]/10 rounded-full blur-[150px] sm:blur-[200px]" />
        <div className="absolute bottom-0 right-1/4 w-48 h-48 sm:w-64 sm:h-64 bg-[#CCFF00]/5 rounded-full blur-[100px] sm:blur-[150px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-8 sm:mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-[#CCFF00]/10 border border-[#CCFF00]/30 mb-4 sm:mb-6">
            <Star className="w-4 h-4 sm:w-5 sm:h-5 text-[#CCFF00]" />
            <span className="text-[#CCFF00] font-semibold text-xs sm:text-sm tracking-wider">PRODUTO PRINCIPAL</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3 sm:mb-4 px-2 sm:px-0">
            Mentalidade de Atleta <span className="text-gradient">Profissional no Tênis</span>
          </h2>
          <p className="text-gray-400 text-base sm:text-lg max-w-3xl mx-auto px-3 sm:px-0">
            O e-book que vai transformar sua performance mental. Aprenda os segredos que os campeões 
            usam para vencer sob pressão.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-start">
          {/* Left - Product Image & Features */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="relative mb-6 sm:mb-8">
              {/* Glow */}
              <div className="absolute inset-0 bg-[#CCFF00]/20 blur-[50px] sm:blur-[80px] rounded-full scale-75" />
              
              <img
                src="/ebook-mockup.png"
                alt="Mentalidade de Atleta Profissional no Tênis"
                className="relative z-10 w-[250px] sm:w-[300px] md:w-[350px] lg:w-full lg:max-w-md mx-auto drop-shadow-2xl"
              />
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-4 gap-2 sm:gap-4">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  className="text-center p-2 sm:p-4 rounded-lg sm:rounded-xl bg-[#0A0A0A] border border-[#2A2A2A]"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                >
                  <feature.icon className="w-4 h-4 sm:w-5 sm:h-5 text-[#CCFF00] mx-auto mb-1 sm:mb-2" />
                  <p className="text-white text-xs sm:text-sm font-bold">{feature.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right - Chapters & Pricing */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            {/* Chapters List */}
            <div className="mb-6 sm:mb-8">
              <h3 className="text-lg sm:text-xl font-bold text-white mb-3 sm:mb-4 flex items-center gap-2">
                <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-[#CCFF00]" />
                O que você vai aprender:
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 sm:gap-2">
                {chapters.map((chapter, index) => (
                  <motion.div
                    key={index}
                    className="flex items-start gap-2 text-sm"
                    initial={{ opacity: 0, x: -10 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.3 + index * 0.03 }}
                  >
                    <Check className="w-3 h-3 sm:w-4 sm:h-4 text-[#CCFF00] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-300 text-xs sm:text-sm">{chapter}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Pricing Card */}
            <div className="bg-[#0A0A0A] rounded-xl sm:rounded-2xl border border-[#2A2A2A] p-4 sm:p-6">
              <div className="text-center mb-4 sm:mb-6">
                <p className="text-gray-400 mb-1 sm:mb-2 text-sm">Investimento:</p>
                <div className="flex items-baseline justify-center gap-2 sm:gap-3">
                  <span className="text-gray-500 line-through text-lg sm:text-xl">R$ 147,00</span>
                  <span className="bg-[#CCFF00] text-black text-xs sm:text-sm font-bold px-1.5 sm:px-2 py-0.5 sm:py-1 rounded">
                    -54%
                  </span>
                </div>
                <div className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mt-1 sm:mt-2">R$ 67,00</div>
                <p className="text-gray-500 mt-0.5 sm:mt-1 text-xs sm:text-sm">ou 12x de R$ 6,74 no cartão</p>
              </div>

              <Button
                className="w-full bg-[#CCFF00] text-black hover:bg-[#9EF916] py-4 sm:py-5 text-base sm:text-lg font-bold rounded-xl animate-pulse-glow transition-transform hover:scale-[1.02] mb-3 sm:mb-4"
                onClick={() => window.open('https://pay.hotmart.com/S104668979W?off=9k8mozwa', '_blank')}
              >
                <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                COMPRAR AGORA
              </Button>

              <div className="flex items-center justify-center gap-2 text-gray-400 text-xs sm:text-sm">
                <Shield className="w-3 h-3 sm:w-4 sm:h-4 text-[#CCFF00]" />
                <span>Garantia de 7 dias</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default MainProduct;
