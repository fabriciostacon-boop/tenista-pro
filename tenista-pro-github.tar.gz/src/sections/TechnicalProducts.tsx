import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Target, Zap, BookOpen, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const TechnicalProducts = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const products = [
    {
      id: 'saque',
      icon: Target,
      title: 'Saque de Elite',
      subtitle: 'Transforme seu saque em uma arma',
      description: 'O saque é o único golpe em que você tem controle total. Aprenda a construir um saque sólido, gerar potência sem machucar o braço e dominar os tipos de saque.',
      features: [
        'Fundamentos do saque perfeito',
        'Biomecânica: potência sem forçar',
        '3 tipos de saque para dominar',
        'Precisão: onde sacar para ganhar',
        'Plano de evolução em 21 dias',
        'Checklist de jogo para imprimir',
      ],
      price: 'R$ 29,90',
      color: '#CCFF00',
      link: 'https://pay.hotmart.com/V104884041C?off=5yozej5n',
    },
    {
      id: 'forehand',
      icon: Zap,
      title: 'Forehand de Elite',
      subtitle: 'Seu golpe mais forte e confiável',
      description: 'O forehand é o golpe mais utilizado no tênis. Construa um forehand consistente, potente e confiável com técnica correta e drills práticos.',
      features: [
        'Base técnica completa',
        'Controle, potência e efeitos',
        'Erros comuns e correções',
        'Treinos práticos (drills)',
        'Preparação física + mental',
        'Plano de evolução em 30 dias',
      ],
      price: 'R$ 29,90',
      color: '#3B82F6',
      link: 'https://pay.hotmart.com/E104883930K?off=5zc8xox8',
    },
    {
      id: 'backhand',
      icon: BookOpen,
      title: 'Backhand Imparável',
      subtitle: 'Domine o lado "fraco" do seu jogo',
      description: 'Transforme seu backhand em um golpe confiável. Aprenda as técnicas de backhand de uma e duas mãos, posicionamento e estratégias de jogo.',
      features: [
        'Backhand de uma e duas mãos',
        'Técnica e biomecânica',
        'Posicionamento ideal',
        'Estratégias de jogo',
        'Drills específicos',
        'Correção de erros comuns',
      ],
      price: 'R$ 29,90',
      color: '#EC4899',
      link: 'https://pay.hotmart.com/V104883700A?off=1ohebnf1',
    },
  ];

  return (
    <section ref={ref} className="relative py-16 sm:py-24 bg-[#0A0A0A] overflow-hidden" id="technical-products">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-[150px]" />
        <div className="absolute top-0 right-1/4 w-64 h-64 bg-pink-500/5 rounded-full blur-[100px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-10 sm:mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2 rounded-full bg-[#2A2A2A] border border-[#3A3A3A] mb-4 sm:mb-6">
            <Target className="w-4 h-4 sm:w-5 sm:h-5 text-[#CCFF00]" />
            <span className="text-gray-300 font-semibold text-xs sm:text-sm tracking-wider">E-BOOKS TÉCNICOS</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3 sm:mb-4">
            Aperfeiçoe Cada <span className="text-gradient">Golpe</span>
          </h2>
          <p className="text-gray-400 text-base sm:text-lg max-w-2xl mx-auto px-2 sm:px-0">
            E-books especializados para transformar seu saque, forehand e backhand. 
            Método prático e aplicável ao seu nível.
          </p>
        </motion.div>

        {/* Products Grid - Alinhado e Responsivo */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              className="group relative bg-[#141414] rounded-2xl border border-[#2A2A2A] overflow-hidden card-hover h-full flex flex-col"
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.15, ease: [0.16, 1, 0.3, 1] }}
            >
              {/* Color Accent Bar */}
              <div 
                className="h-1.5 w-full flex-shrink-0" 
                style={{ backgroundColor: product.color }}
              />

              <div className="p-4 sm:p-6 flex flex-col flex-grow">
                {/* Icon & Title */}
                <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                  <div 
                    className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${product.color}20` }}
                  >
                    <product.icon className="w-6 h-6 sm:w-7 sm:h-7" style={{ color: product.color }} />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-lg sm:text-xl font-bold text-white truncate">{product.title}</h3>
                    <p className="text-gray-500 text-xs sm:text-sm truncate">{product.subtitle}</p>
                  </div>
                </div>

                {/* Description */}
                <p className="text-gray-400 text-sm mb-4 sm:mb-6 leading-relaxed">
                  {product.description}
                </p>

                {/* Features - Flex-grow para empurrar o preço para baixo */}
                <ul className="space-y-2 mb-4 sm:mb-6 flex-grow">
                  {product.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: product.color }} />
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Price & CTA - Sempre no final */}
                <div className="pt-4 border-t border-[#2A2A2A] mt-auto">
                  <div className="flex items-baseline gap-2 mb-3 sm:mb-4">
                    <span className="text-2xl sm:text-3xl font-bold text-white">{product.price}</span>
                  </div>
                  <Button
                    className="w-full py-4 sm:py-5 font-bold rounded-xl transition-all hover:scale-[1.02] text-sm sm:text-base"
                    style={{ 
                      backgroundColor: product.color,
                      color: product.color === '#CCFF00' ? '#000' : '#fff'
                    }}
                    onClick={() => window.open(product.link, '_blank')}
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    COMPRAR
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TechnicalProducts;
